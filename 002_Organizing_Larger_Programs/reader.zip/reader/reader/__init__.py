'''
Reader package
@author: ArchKudo
'''

# Using relative imports
# Similar to reader.reader
from .reader import Reader

print('Importing pkg...')
